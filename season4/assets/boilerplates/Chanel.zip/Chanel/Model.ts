export const items = [
  {
    title: "Upcoming Show Live from Paris",
    subtitle: "SPRING-SUMMER 2021",
    picture: require("./assets/chanel.jpg"),
    top: 0,
  },
  {
    title: "In Boutiques",
    subtitle: "FALL-WINTER 2020/21",
    picture: require("./assets/sonnie-hiles-pU4J5VFnqCQ-unsplash-with-gradient.jpg"),
    top: 0,
  },
  {
    title: "Deauville Film Festival",
    subtitle: "CHANEL IN CINEMA",
    picture: require("./assets/laura-chouette-NFrPPyGe5q0-unsplash-with-gradient.jpg"),
    top: 0,
  },
  {
    title: "IN BOUTIQUES",
    subtitle: "Métiers d'art 2019/20",
    picture: require("./assets/butsarakham-buranaworachot-au6Gddf1pZQ-unsplash.jpg"),
    top: 0,
  },
  {
    title: "Haute Couture",
    subtitle: "FALL-WINTER 2020/21",
    picture: require("./assets/khaled-ghareeb-upepKTbwm3A-unsplash.jpg"),
    top: 50,
  },
  {
    title: "Balade en Méditerranée",
    subtitle: "CRUISE 2020/21",
    picture: require("./assets/christopher-campbell-A3QXXEfcA1U-unsplash.jpg"),
    top: 0,
  },
  {
    title: "Spring-Summer 2020 Campaign",
    subtitle: "EYEWEAR",
    picture: require("./assets/chase-fade-Pb13EUxzMDw-unsplash.jpg"),
    top: 0,
  },
];
