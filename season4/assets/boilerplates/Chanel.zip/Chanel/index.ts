export { default } from "./Chanel";
import { items } from "./Model";

export const assets = items.map((item) => item.picture);
